#ifndef IDENTIFIER_H
#define IDENTIFIER_H

#include <stdint.h>
#include <stdio.h>

uint8_t* parse_identifier(int argc, char* argv[]);

#endif // !IDENTIFIER_H
